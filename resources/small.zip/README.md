# SecureCodingParser

Program expects one input parameter - path to the ZIP file.

Parser expects PK format of ZIP - https://users.cs.jmu.edu/buchhofp/forensics/formats/pkzip.html
